Hi, and welcome to Iknow Channel.
This Package was build By Iknow for the 4th episode of Operating system development Series:
https://www.youtube.com/watch?v=rr-9w2gITDM&list=PLBK_0GOKgqn3hjBdrf5zQ0g7UkQP_KLC3

Thank You for Watching And thank you for subscribing at www.youtube.com/iknowbrain

To download the needed tools to compile this kernel check The description of the video (Episode 4 in os dev):
https://www.youtube.com/watch?v=znnGBx2HlsY


